<?php session_start();
 
 
	$part= $_SERVER['HTTP_REFERER'];
	 
 
	 
	 
	 

if( !isset($_GET['set'])){
	echo "";
	}
	
if ($_GET['set']=='default') {
		
		$_SESSION["css"]="css/mysite.css";
		$_SESSION["msg"]="Default";
		$_SESSION["why"]="This is the default look of the site";
		 $_SESSION["look0"]="style";
		} else {$_SESSION["look0"]="style2";}
			

if ($_GET['set']=='ada') {
		
		$_SESSION["css"]="css/ada.css";
		$_SESSION["msg"]="ADA";
		$_SESSION["why"]="This look is for ADA Accessibility";
		 $_SESSION["look1"]="style";
		 $selectedBg =" ";
		} else {$_SESSION["look1"]="style2";}
		
if($_GET['set']=='burrito')  {
		
		$_SESSION["css"]="css/burrito.css";
		$_SESSION["msg"]="Burrito";
		$_SESSION["why"]="This look is just for fun";
		 $_SESSION["look2"]="style";
		}else {$_SESSION["look2"]="style2";}
		
if   ( !isset($_SESSION["css"]) )
	{$_SESSION["css"]="css/mysite.css";
		$_SESSION["msg"]="Default";
		 $_SESSION["look0"]="style";
	   
        }
		
		
header("Location: $part");
exit(); ?>